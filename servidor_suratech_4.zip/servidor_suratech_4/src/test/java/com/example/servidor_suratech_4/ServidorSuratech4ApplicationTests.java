package com.example.servidor_suratech_4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServidorSuratech4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
