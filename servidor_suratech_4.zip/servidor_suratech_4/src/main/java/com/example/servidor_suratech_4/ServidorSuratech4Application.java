package com.example.servidor_suratech_4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServidorSuratech4Application {

	public static void main(String[] args) {
		SpringApplication.run(ServidorSuratech4Application.class, args);
	}

}
